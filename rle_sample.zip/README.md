# Sample Test Cases 

This testing consists of 5 files naming from sample1.txt to sample5.txt.

### Sample1.txt

```Sample1.txt``` consists of only repeating sequence of character '0' and '1'. In more detail, '0' repeats 256 times and '1' repeats 256 times, then the whole sequence repeats itself again.

### Sample2.txt

```Sample2.txt``` contains lower alphabetic letters from 'a' to 'z' in the following format.

```
a
bb
ccc
dddd
...
```
'a' appears once; 'b' appears twice; 'c' appears 3 times and so on.

### Sample3.txt

```Sample3.txt``` is a repeated version of ```Sample2.txt```, where the whole pattern repeats 1024 times.

### Sample4.txt

Consider the following matrix:

```
000...0
111...1
222...2
...
999...9

```
```Sample4.txt``` consists of such matrix which has 1024 rows, and each row has 2048 numerical digits. The whole file contains no new lines symbols.

### Sample5.txt

```Sample5.txt``` is made up of 1 MB of the character 'a' followed by 199 MB of the character 'b'.